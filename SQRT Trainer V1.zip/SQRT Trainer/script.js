// Simple Square Root Speed Trainer
// Behavior:
// - Generate random 2-digit integer (10..99)
// - Show its square, start timer (0.1s precision)
// - Display input; user types the original two-digit number
// - If correct and Enter pressed: stop timer, log elapsed time and square
// - If wrong: do nothing and timer continues
// - Ability to delete individual logs, or clear all

(() => {
  const generateBtn = document.getElementById('generateBtn');
  const roundArea = document.getElementById('roundArea');
  const squareNumberEl = document.getElementById('squareNumber');
  const timerEl = document.getElementById('timer');
  const answerForm = document.getElementById('answerForm');
  const answerInput = document.getElementById('answerInput');
  const resultMessage = document.getElementById('resultMessage');
  const logList = document.getElementById('logList');
  const clearAllBtn = document.getElementById('clearAllBtn');

  let currentRoot = null;
  let currentSquare = null;
  let startTime = null;
  let timerId = null;
  let logs = [];

  // Load logs from localStorage (optional)
  try {
    const saved = localStorage.getItem('sqrt-trainer-logs');
    if (saved) logs = JSON.parse(saved);
  } catch (e) {
    logs = [];
  }
  renderLogs();

  function saveLogs(){
    try { localStorage.setItem('sqrt-trainer-logs', JSON.stringify(logs)); } catch(e){}
  }

  function randomTwoDigit(){
    return Math.floor(Math.random() * 90) + 10; // 10..99
  }

  function startRound(){
    currentRoot = randomTwoDigit();
    currentSquare = currentRoot * currentRoot;
    squareNumberEl.textContent = String(currentSquare);
    resultMessage.textContent = '';
    timerEl.textContent = '0.0 s';
    answerInput.value = '';
    answerInput.focus();

    generateBtn.disabled = true;
    generateBtn.classList.add('hidden');
    roundArea.classList.remove('hidden');

    startTime = performance.now();
    timerId = setInterval(updateTimer, 50); // update every 50ms
  }

  function updateTimer(){
    const elapsed = (performance.now() - startTime) / 1000;
    timerEl.textContent = elapsed.toFixed(1) + ' s';
  }

  function stopRoundAndLog(){
    if (timerId) clearInterval(timerId);
    const elapsed = (performance.now() - startTime) / 1000;
    const elapsedFixed = Number(elapsed.toFixed(1)); // one decimal
    resultMessage.textContent = `Your time was ${elapsedFixed} s.`;
    // Add to logs (square shown first per your example)
    logs.unshift({
      square: currentSquare,
      root: currentRoot,
      time: elapsedFixed,
      at: new Date().toISOString()
    });
    saveLogs();
    renderLogs();
    // reset UI
    roundArea.classList.add('hidden');
    generateBtn.disabled = false;
    generateBtn.classList.remove('hidden');
    currentRoot = null;
    currentSquare = null;
    startTime = null;
    timerId = null;
  }

  // Handle answer submission (enter key)
  answerForm.addEventListener('submit', (e) => {
    e.preventDefault();
    // Only accept if a round is active
    if (!startTime || !currentRoot) return;

    const val = answerInput.value.trim();
    if (!/^\d{1,2}$/.test(val)) {
      // ignore invalid format
      return;
    }
    const numeric = Number(val);
    if (numeric === currentRoot) {
      stopRoundAndLog();
    } else {
      // wrong answer: do nothing (per spec)
      // Optionally we could flash or shake, but user requested no action
    }
  });

  // Generate button
  generateBtn.addEventListener('click', () => {
    // start a new attempt
    startRound();
  });

  // Render logs in order (most recent first). You can change to push to end if you prefer oldest-first.
  function renderLogs(){
    logList.innerHTML = '';
    if (logs.length === 0){
      const li = document.createElement('li');
      li.className = 'log-item';
      li.textContent = 'No attempts yet.';
      logList.appendChild(li);
      return;
    }

    logs.forEach((entry, idx) => {
      const li = document.createElement('li');
      li.className = 'log-item';

      const left = document.createElement('div');
      left.style.display = 'flex';
      left.style.alignItems = 'center';

      const label = document.createElement('div');
      label.className = 'log-label';
      label.textContent = `${entry.square} —`;

      const time = document.createElement('div');
      time.className = 'log-time';
      time.textContent = ` ${entry.time} s`;

      left.appendChild(label);
      left.appendChild(time);

      const actions = document.createElement('div');
      actions.className = 'log-actions';

      const del = document.createElement('button');
      del.type = 'button';
      del.title = 'Delete this log';
      del.textContent = 'Delete';
      del.addEventListener('click', () => {
        logs.splice(idx, 1);
        saveLogs();
        renderLogs();
      });

      actions.appendChild(del);

      li.appendChild(left);
      li.appendChild(actions);

      logList.appendChild(li);
    });
  }

  clearAllBtn.addEventListener('click', () => {
    if (!logs.length) return;
    if (confirm('Clear all logs?')) {
      logs = [];
      saveLogs();
      renderLogs();
    }
  });

  // Accessibility: pressing Escape should cancel current round and show Generate again
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      if (timerId) {
        clearInterval(timerId);
        timerId = null;
        startTime = null;
        roundArea.classList.add('hidden');
        generateBtn.disabled = false;
        generateBtn.classList.remove('hidden');
        resultMessage.textContent = 'Attempt canceled.';
      }
    }
  });

  // Initial UI state
  roundArea.classList.add('hidden');
})();